"""CitiBike pipeline."""
