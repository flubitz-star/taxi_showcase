"""NYC taxi pipeline."""
