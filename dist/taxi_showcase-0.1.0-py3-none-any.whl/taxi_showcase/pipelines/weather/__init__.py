"""Weather pipeline."""
